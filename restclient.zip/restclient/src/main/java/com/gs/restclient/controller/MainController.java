package com.gs.restclient.controller;

import com.gs.restclient.domain.Greeting;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.ui.ModelMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;

@Controller
public class MainController {

	private static final String MAIN_PAGE = "main";
	
	@Value("${JSON.GREETING.URL:http://9.60.87.89:2345/greeting}")
	private String JSON_GREETING_URL;
	
	@GetMapping
        public String main(final ModelMap model) {
	final RestTemplate restTemplate = new RestTemplate();
	final Greeting greeting = restTemplate.getForObject(JSON_GREETING_URL, Greeting.class);
	model.addAttribute( "greeting" , greeting);
        return MAIN_PAGE;
        }

}
