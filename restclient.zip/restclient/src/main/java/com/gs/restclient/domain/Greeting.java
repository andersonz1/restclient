package com.gs.restclient.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties

public class Greeting {

	private  long id;
	private  String content;
        private  String ipclient;

	public long getId() {
		return id;
	}
	public void setId(long id){
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	 public void setContent(String content){
                this.content = content;
	 }
	public String getIpclient() {
                return ipclient;
        }
	public void setIpclient(String ipclient){
                this.ipclient = ipclient;
	}

}
